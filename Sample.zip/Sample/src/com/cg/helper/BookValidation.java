package com.cg.helper;

import java.util.regex.Pattern;

import exceptionpackage.Bookexception;

public class BookValidation {

	public static boolean validatebookName(String bookName)
			throws Bookexception {

		String custPattern = "[A-Z][A-Za-z]{5,20}";
		if (Pattern.matches(custPattern, bookName)) {
			return true;
		} else {
			throw new Bookexception(
					"Book name should start with capital and have a max length of 20");
		}
	}

	public static boolean validatebookID(String bookID) throws Bookexception {
		String Idpattern = "\\d{3}";
		if (Pattern.matches(Idpattern, bookID)) {
			return true;
		} else {
			throw new Bookexception("Only 3-digit bookID is allowed");

		}
	}

	public static boolean validatebookPrice(String bookPrice)
			throws Bookexception {
		String pricepattern = "\\d{2,4}.?[0-9]{2}$";
		if (Pattern.matches(pricepattern, bookPrice)) {
			return true;
		}

		else {
			throw new Bookexception("Book price incorrect");
		}
	}

}
package assignment;
import java.util.Scanner;
public class Pstvneg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int n;
Scanner s=new Scanner(System.in);
System.out.println("Enter the number:");
n=s.nextInt();
if(n>0){
	System.out.println("The given number "+n+" is positive ");
}
else if(n<0)
{
	System.out.println("The given number "+n+" is negative ");
}
	}

}

package LabAssignment;

public class PersonalDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				System.out.println("Person Details");
				System.out.println("-----------------\n");
				System.out.println("First Name:Divya");
				System.out.println("Last Name:Bharathi");
				System.out.println("Gender: F");
				System.out.println("Age: 20");
				System.out.printf("Weight: 85.55");
				

	}

}

package com.capgemini.trg.lab4;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.StringBuffer;

public class Reverse {
	public static void main(String[] args)
	  {
	      try{
	   // Open the file that is the first
	    // command line parameter
	    FileInputStream fstream = new FileInputStream("D:\\File.txt");
	    // Get the object of DataInputStream
	  DataInputStream in = new DataInputStream(fstream);
	    BufferedReader br = new BufferedReader(new InputStreamReader(in));
	    String strLine;
	    //Read File Line By Line
	    while ((strLine = br.readLine()) != null)   {
	      // Print the content on the console
	        System.out.println (strLine);
	        String str="";
	        for(int i=strLine.length()-1;i>1;i--)
	        {
	        	str=str+strLine.charAt(i);
	        	
	        }
	        System.out.println("File Reversed is" +str);
	       
	    }
	    //Close the input stream
	    in.close();
	    }catch (Exception e){//Catch exception if any
	      System.err.println("Error: " + e.getMessage());
	    }
	  }

}

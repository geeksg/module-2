package com.cg.age;

public class PersonAge {
float age;
PersonAge()
{
	
}
public float getAge()
{
	return age;
}
public void setAge(float age)
{
	this.age=age;
}
public void display()
{
	System.out.println("Age is: "+age);
}
}

package com.cg.age;
import java.util.Scanner;
public class AgeMain {
public static void isValid(float age) throws AgeException
{
	if(age<=15)
	{
		throw new AgeException(age);
	}
}
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	PersonAge p=new PersonAge();
	System.out.println("Enter the Age: ");
	float age=sc.nextFloat();
	p.setAge(age);
	try
	{
		isValid(age);
		p.display();
		sc.close();
	}
	catch(AgeException e)
	{
		e.printError();
	}
}
}

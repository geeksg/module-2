package com.cg.age;

public class AgeException extends Exception{

	private static final long serialVersionUID=1L; 
	private float age;
	public AgeException(float age)
	{
		this.setAge(age);
	}
	
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	public void printError()
	{
		System.out.println("age should be above 15! ");
	}
	}

package com.cg.eis.service;

import java.util.ArrayList;
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class ServiceImpl implements Service {
 @Override
 public void getScheme(Employee emp) throws EmployeeException{
	 
	 if((emp.getSalary()<5000)&& (emp.getDesignation().equalsIgnoreCase("Clerk"))){
		 emp.setInsScheme("No Scheme");
		 
	 }
	 
	 else if((emp.getSalary()>5000)&&(emp.getSalary() < 20000)&&(emp.getDesignation().equalsIgnoreCase("System Associate"))){
	 		emp.setInsScheme("Scheme C");
	 }
	 
	 else if ((emp.getSalary()>=20000)&& (emp.getSalary()<40000)&&(emp.getDesignation().equalsIgnoreCase("Programmer"))){
		 emp.setInsScheme("Scheme B");
	 }
	 
	 else if((emp.getSalary()>=40000)&&(emp.getDesignation().equalsIgnoreCase("Manager"))){
		 emp.setInsScheme("Scheme A");
	 }
	 
	 else{
		 emp.setInsScheme("Scheme not available");
	 }
 }
 
 @Override
 public void displayEmployees(ArrayList<Employee> arr) throws EmployeeException{
	 for(Employee employee : arr){
		 System.out.println(employee);
	 }
 }
}

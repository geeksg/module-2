package com.cg.eis.service;

import java.util.ArrayList;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;


public interface Service {

	void getScheme(Employee emp) throws EmployeeException;
	void displayEmployees(ArrayList<Employee> arr) throws EmployeeException;
}

package com.cg.eis.bean;

public class Employee {

	private int empid;
	private String ename;
	private double salary;
	private String designation;
	private String insScheme;
	
	public Employee() {
		super();
	}


	public Employee(int empid, String ename, double salary, String designation, String insScheme){
		
		super();
		this.empid=empid;
		this.ename=ename;
		this.salary=salary;
		this.designation=designation;
		this.insScheme=insScheme;
	}
	
	@Override
	public String toString(){
		return "Employee [empid="+empid+", ename="+ename+", salary="+salary+",designation="+ designation+",insScheme="+ insScheme+ "]";
	}
	
	public void setEmpid(int empid){
		this.empid=empid;
	}
	
	public String getEname(){
		return ename;
	}
	
	public void setEname(String ename){
		this.ename=ename;
	}
	
	public double getSalary(){
		return salary;
	}
	
	public void setSalary(double salary){
		this.salary=salary;
	}
	
	public String getDesignation(){
		return designation;
	}
	
	public void setDesignation(String insScheme){
		this.designation=designation;
	}
	public String getInsScheme(){
		return insScheme;
	}
	
	public void setInsScheme(String insScheme){
		this.insScheme=insScheme;
	}
	
	public int getEmpid(){
		return empid;
	}
}

package com.cg.eis.pl;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.Service;
import com.cg.eis.service.ServiceImpl;
public class Executor {

	public static void main(String[] args) throws EmployeeException {
		
		System.out.println("*****************Employee Services************");
		Scanner sc=new Scanner(System.in);
		Scanner sc1 =new Scanner(System.in);
		Employee emp=new Employee();
		ArrayList<Employee> arr = new ArrayList<Employee>();
		String a[]=new String[5];
		a[0]="java";
		a[1]=".net";
		a[2]="testing";
		a[3]="c#";
		a[4]="selenium";
		
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
		Service ser = new ServiceImpl();
		int option = 0;
		do{
			System.out.println("\n1. Add employee details");
			System.out.println("2. Display all employee details");
			System.out.println("3. Exit");
			option = sc.nextInt();
			
			switch (option){
			case 1: System.out.println("Enter employee ID");
			int id = sc.nextInt();
			emp.setEmpid(id);
			System.out.println("Enter employee name");
			String name=sc1.nextLine();
			emp.setEname(name);
			System.out.println("Enter salary of the employee");
			double sal = sc.nextDouble();
			if(sal<3000){
				throw new EmployeeException("Salary cannot be less than 3000");
			}
			emp.setSalary(sal);
			System.out.println("Enter the designation");
			String desg=sc1.nextLine();
			emp.setDesignation(desg);
			try{
				ser.getScheme(emp);
			}catch(EmployeeException e){
				e.printStackTrace();
			}
			System.out.println("Employee details added successfully...");
			System.out.println("And your Insurance Scheme is :"+ emp.getInsScheme());
			arr.add(emp);
			for(Employee employee :arr){
				System.out.println(employee);
			}
			break;
			case 2: ser.displayEmployees(arr);
			break;
			case 3: System.out.println("Application Closed");
			break;
			default: System.out.println("Wrong choice, Try again...!");
			break;
			}
		}while(option != 3);
	}
}

package bean;

public class employeed {
	 String Designation;
	 String Insurancescheme;
	 int Salary;
	public employeed() {}
	public employeed(String designation, String insurancescheme, int salary) {
		
		Designation = designation;
		Insurancescheme = insurancescheme;
		Salary = salary;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getInsurancescheme() {
		return Insurancescheme;
	}
	public void setInsurancescheme(String insurancescheme) {
		Insurancescheme = insurancescheme;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	@Override
	public String toString() {
		return "employeed [Designation=" + Designation + ", Insurancescheme="
				+ Insurancescheme + ", Salary=" + Salary + "]";
	}
	
	

}


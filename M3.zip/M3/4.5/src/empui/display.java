package empui;
import java.util.Scanner;

import employee.employeeDetails;
public class display {
	//private static final scheme c = null;
	static Scanner sc=new Scanner(System.in);
	static employeeDetails emp=null;
	public static void main(String[] args) {
		int choice=0;
		emp=new employeeDetails();
		while(true)
		{
			System.out.println("1:Add employee details \n"+
					"2:display details \n3:Exit");

			System.out.println("\nEnter UR Choice: ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:enteremployeeDetails();break;
			//case 2: collectionhelper.displayBookCount();break;
			default:System.out.println("\nProcess got terminated");System.exit(0);			
			}
		}
	}
	private static void enteremployeeDetails() 
	{
		
		System.out.println("Enter count of employee details to be entered ");
		
		int bcount =sc.nextInt();
		
		System.out.println("Enter scheme:");
		String des=sc.next();
		//String des1="";
		
		//String schemeC=null;
		if(des=="schemeC")
		{
			System.out.println("System Associate");
		}
		else if(des=="scheme B"){
			System.out.println("Programmer");
		}
		else if(des=="scheme A"){
			System.out.println("Manager");
		}
		else {
			System.out.println("Clerk");
		}
		}
}

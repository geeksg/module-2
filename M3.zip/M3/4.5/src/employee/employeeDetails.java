package employee;
import java.util.HashSet;
import java.util.Iterator;
import bean.employeed;
public class employeeDetails {
	private  static HashSet<employeed> emplist=null;
	static
	{
		emplist=new HashSet<employeed>();
		employeed e1=new employeed("System Associate","Scheme C",5000);
		employeed e2=new employeed("Programmer","Scheme B",4000);
		employeed e3=new employeed("Manager","Scheme A",2000);
		employeed e4=new employeed("Clerk","No Scheme",1000);
		emplist.add(e1);
		emplist.add(e2);
		emplist.add(e3);
		emplist.add(e4);
		
	}
public employeeDetails(){}
	
	/*************Add New employee details in Hashset************/
	public void addNewemployeeDetails(employeed emp1) 
	{			
			emplist.add(emp1);				
	}
	
	
	public static HashSet<employeed> getEmplist() {
		return emplist;
	}

	public static void setEmplist(HashSet<employeed> emplist) {
		employeeDetails.emplist = emplist;
	}

	public static  void displayempdetails()
	{
		Iterator<employeed> empIt=emplist.iterator();
		employeed tempemp=null;
		
		int totalCount=0;
		while(empIt.hasNext())
		{
			totalCount++;
			tempemp=empIt.next();
			System.out.println(tempemp);			
		}
		System.out.println("Employee details" + totalCount);
	}

}

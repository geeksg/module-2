package com.cg.eis.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public abstract class ServiceImpl implements Service {
 public InputStream fileIs;

@Override
 public void getScheme(Employee emp) throws EmployeeException{
	 
	 if((emp.getSalary()<5000)&& (emp.getDesignation().equalsIgnoreCase("Clerk"))){
		 emp.setInsScheme("No Scheme");
		 
	 }
	 
	 else if((emp.getSalary()>5000)&&(emp.getSalary() < 20000)&&(emp.getDesignation().equalsIgnoreCase("System Associate"))){
	 		emp.setInsScheme("Scheme C");
	 }
	 
	 else if ((emp.getSalary()>=20000)&& (emp.getSalary()<40000)&&(emp.getDesignation().equalsIgnoreCase("Programmer"))){
		 emp.setInsScheme("Scheme B");
	 }
	 
	 else if((emp.getSalary()>=40000)&&(emp.getDesignation().equalsIgnoreCase("Manager"))){
		 emp.setInsScheme("Scheme A");
	 }
	 
	 else{
		 emp.setInsScheme("Scheme not available");
	 }
 }
 
 public class MyObjectFileStore{
		public void storeObject(Employee emp){
	OutputStream ops=null;
	ObjectOutputStream objOps=null;
	try{
		ops=new FileOutputStream("MYEmpFile.txt");
		objOps=new ObjectOutputStream(ops);
		objOps.writeObject(emp);
		objOps.flush();
	}catch(FileNotFoundException e){
		e.printStackTrace();
	}catch(IOException e){
	e.printStackTrace();
	}finally{
	try{
		if(objOps != null) objOps.close();
	}catch(Exception ex){
	}
	}
	}


	public void displayObjects(){
		InputStream fields=null;
		ObjectInput objIs=null;
		try{
		fields=new FileInputStream("MyEmpFile.txt");
		objIs=new ObjectInputStream(fileIs);
		Employee emp=(Employee) objIs.readObject();
		System.out.println(emp);
	}catch(FileNotFoundException e){
		e.printStackTrace();
	}catch (IOException e){
		e.printStackTrace();
	}catch(ClassNotFoundException e){
		e.printStackTrace();
	}finally{
		try{
			if(objIs != null) objIs.close();
		}catch (Exception ex){
	}
	}
	}
 
 public void main(String[] args){
	 MyObjectFileStore mof=new MyObjectFileStore();
	 Employee e1=new Employee(101,"karthik",50000,"analyst", null);
	 mof.storeObject(e1);
	 mof.displayObjects();
	 }
 }
}

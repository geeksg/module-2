package lab3_1;

public class BlankException extends Exception {
	private static final long serialVerssionUID=1L;
	private String fName;
	
	public  BlankException(String message)
	{
        super(message);
    }
	
}

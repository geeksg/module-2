package lab3_1;


import java.util.Scanner;

import lab3_1.Person;


public class PersonMain {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		Person p1 = new Person();
		
		System.out.println("Person Details: ");
		System.out.println("______________");
		System.out.println("\n");
		System.out.print("First Name: ");
		String fName=sc.next();
		if(fName!=null)
		{
		  System.out.print("Last Name: ");
		  String lName=sc.next();
		   if(lName!=null)
		   {
	         System.out.print("Gender: ");
	         String gender=sc.next();
	         
		   }
		  
		}
		
}

}

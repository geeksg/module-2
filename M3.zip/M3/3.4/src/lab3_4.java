
import java.util.*;

public class lab3_4 {
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n;
		String temp;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter number strings you want to enter");
		n=s.nextInt();
		String strs[]=new String[n];
		Scanner s1=new Scanner(System.in);
		System.out.println("Enter Strings:");
		for(int i=0;i<n;i++)
		{
			strs[i]=s1.next();
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(strs[i].compareTo(strs[j])<0)
				{
					temp=strs[i];
					strs[i]=strs[j];
					strs[j]=temp;
				}
			}
		}
		System.out.println("Sorted list");
		for(int i=0;i<n;i++)
		{
			System.out.println(strs[i]);
		}
		
	}

	}


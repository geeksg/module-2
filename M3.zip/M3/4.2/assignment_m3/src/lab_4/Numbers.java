package lab_4;
import java.util.*;
import java.io.*;

public class Numbers {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		File file=new File("D:\\numbers.txt");
		try{
		Scanner sc=new Scanner(file);
		String st;
		while (sc.hasNextLine())
			System.out.println(sc.nextLine());
		}
		catch (IOException e)
		{
			System.out.println("unable to open file '" +file +"'");
		}
		int i;
		int a[]={1,2,3,4,5,6,7,8,9,10};
		for(i=0;i<a.length;i++)
		{
			if(a[i]%2==0){
				System.out.println(a[i]);
			}
		}
		
			
			


}
}